# Data and Telecommunication
# Fixed some bugs of earlier version of Practical_03
Developed an encoder and a decoder for Line Coding (2B1Q and MLT-3) and Scrambling (B8ZS and HDB3). Please use the input text file "encodeInput.txt" to encode and the input text file "decodeInput.txt" to decode. All the outputs are saved in separated output files too according to their scheme names.